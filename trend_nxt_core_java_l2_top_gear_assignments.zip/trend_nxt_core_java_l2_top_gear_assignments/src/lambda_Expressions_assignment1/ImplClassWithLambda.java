package lambda_Expressions_assignment1;

public class ImplClassWithLambda{
	
	
	public static void main(String[] args) {
		
		/*String stringVal = "Test it";
		char charVal ='t';*/
		//call interface (argument-list) -> {body} 
		CharacterOccurrence charOccurrence =(stringVal, charVal)->{
			int count =0;
			stringVal =stringVal.toLowerCase();
			for(int i=0; i<stringVal.length(); i++) {
				if(stringVal.charAt(i) == charVal) {
					count++;
				}
			}
			
			return count;
		};
		
		System.out.println("No of occurrence is "+charOccurrence.findOccurence("Test ittttt", 't'));
	}
}
