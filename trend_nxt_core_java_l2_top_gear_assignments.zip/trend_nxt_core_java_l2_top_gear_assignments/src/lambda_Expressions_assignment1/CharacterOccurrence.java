package lambda_Expressions_assignment1;

public interface CharacterOccurrence {
	public abstract int findOccurence(String str, char c);
}
