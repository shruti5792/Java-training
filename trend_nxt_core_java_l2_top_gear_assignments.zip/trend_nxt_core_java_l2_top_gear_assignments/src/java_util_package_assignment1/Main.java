package java_util_package_assignment1;


public class Main {

	public static void main(String[] args) {
		ReadWriteClass readWriteClass = new ReadWriteClass();
		readWriteClass.writeinFile();
		readWriteClass.readFromFile();
	}
	
	
}

