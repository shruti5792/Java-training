package java_util_package_assignment1;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;

public class ReadWriteClass {
	
	public void writeinFile(){
		FileWriter fw= null;
	//Date Object
	Date date = new Date();
	
	//Double object
	Double doub = new Double(10.00);
	
	//Long Object
	Long lon = new Long(10L);
			
	//Writing into file
	try {
	fw=new FileWriter("C:\\Users\\Shruti\\Desktop\\output.txt"); 
	fw.write("date is "+date);
	fw.write("Double is "+doub);
	fw.write("Long is "+lon);
	}
	catch(Exception e) {
		System.out.println("Exception occured:: "+e);
	}
	finally {
	try {
		if(fw !=null)
		fw.close();
	} catch (IOException e) {
		System.out.println("Exception occured:: "+e);
	}
}}
	public void readFromFile()  {
		int ch; 
		  
        // check if File exists or not 
        FileReader fr=null; 
        try
        { 
            fr = new FileReader("C:\\Users\\Shruti\\Desktop\\output.txt"); 
        } 
        catch (FileNotFoundException fe) 
        { 
            System.out.println("File not found"); 
        } 
  
        // read from FileReader till the end of file 
        try {
			while ((ch=fr.read())!=-1) 
			    System.out.print((char)ch);
		} catch (IOException e) {
			System.out.println("Exception occured:: "+e);
		} 
  finally {
        // close the file 
        try {
			fr.close();
		} catch (IOException e) {
			System.out.println("Exception occured:: "+e);
		}
  }
	}


}
