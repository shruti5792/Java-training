package java_lang_package_assignment2;

public class Main {

	public static void main(String[] args) {
		
		//Creating objects
		Test test = new Test();
		test = new Test();
		test = new Test();
		
		//It is called 2 times
		 Runtime.getRuntime().gc();
	}

}
