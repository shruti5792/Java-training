package java_lang_package_assignment2;

public class Test {
	
	public Test() {
		System.out.println("Constructor called");
	}

	protected void finalize() throws Throwable
	{
		System.out.println("Finalize method called");
	}
}
