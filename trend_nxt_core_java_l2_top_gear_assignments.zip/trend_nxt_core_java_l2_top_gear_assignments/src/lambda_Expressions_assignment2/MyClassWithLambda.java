package lambda_Expressions_assignment2;

public class MyClassWithLambda {

	public static void main(String[] args) {
		WordCount wordCount = (stringVal) -> {
			stringVal = stringVal.trim();
			String [] noOfWords = stringVal.split(" ");
			return noOfWords.length;
		};
		
		System.out.println(wordCount.count("This is testing for counting no of words "));
	}
}
