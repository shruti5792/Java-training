package lambda_Expressions_assignment2;

public interface WordCount {

	public abstract int count(String str);
}
