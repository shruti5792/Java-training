package java_util_package_assignment2;

import java.time.LocalDate;
import java.time.Period;

public class CalculateDateDiff {

	public void calculate(LocalDate date1, LocalDate date2) {
		
	     Period diff = Period.between(date1, date2); 
	     System.out.println("\nDifference between "+ date1 +" and "+ date2 +": " 
	     + diff.getYears() +" Year(s) and "+ diff.getMonths() +" Month()s\n");
	}
}
