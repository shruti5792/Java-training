package java_util_package_assignment2;

import java.time.LocalDate;
import java.time.Month;

public class Main {

	public static void main(String[] args) {
		CalculateDateDiff calculateDateDiff = new CalculateDateDiff();
		
		//Send date1 and date2
		
		LocalDate date1 = LocalDate.of(2019, Month.JUNE, 04);    
	     LocalDate date2 = LocalDate.of(2015, Month.MAY, 15); 
	     
		calculateDateDiff.calculate(date1, date2);
	}
	
	
}

