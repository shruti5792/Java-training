package java_io_package_assignment1;


public class Main {

	public static void main(String[] args) {
		
		LogicClass logicClass =new LogicClass();
		logicClass.writeRandomNo();
		logicClass.findAverage();
		logicClass.findSum();
	}

}
