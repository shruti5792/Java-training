package java_io_package_assignment1;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.util.Random;

public class LogicClass {
	
	public void writeRandomNo() {
		Writer  fileOutputStream = null;
	
	//Writing into file
	try {
		fileOutputStream = new FileWriter("C:\\Users\\Shruti\\Desktop\\writeRandomNo.txt"); 
	Random random = new Random();
	for(int i=0; i<30; i++) {
		int num = random.nextInt(30) + 1;
		fileOutputStream.write(String.valueOf(num));
		fileOutputStream.write("\n");
	}
	}
	catch(Exception e) {
		System.out.println("Exception occured:: "+e);
	}
	finally {
	try {
		if(fileOutputStream !=null)
			fileOutputStream.close();
	} catch (IOException e) {
		System.out.println("Exception occured:: "+e);
	}
}
	}
	
	public void findAverage() {
		Reader file = null;
		
		try {
			file = new FileReader("C:\\Users\\Shruti\\Desktop\\writeRandomNo.txt");
			BufferedReader bufferedReader = new BufferedReader(file);
			
			String line;
			int count =0;
			int aver=0;
			while ((line = bufferedReader.readLine()) != null && count <10) {
				aver = aver+Integer.parseInt(line);
				count++;
			}
			System.out.println("Average of first 10 num is "+aver/10);
		}
		catch(Exception e) {
			System.out.println("Exception occured:: "+e);
		}
		finally {
		try {
			if(file !=null)
				file.close();
		} catch (IOException e) {
			System.out.println("Exception occured:: "+e);
		}
	}
		
	}
	public void findSum() {
		Reader file = null;
		
		try {
			file = new FileReader("C:\\Users\\Shruti\\Desktop\\writeRandomNo.txt");
			BufferedReader bufferedReader = new BufferedReader(file);
			
			String line;
			int count =0;
			int sum=0;
			while ((line = bufferedReader.readLine()) != null && count <10) {
				sum = sum+Integer.parseInt(line);
				count++;
			}
			System.out.println("Sum of first 10 num is "+sum);
		}
		catch(Exception e) {
			System.out.println("Exception occured:: "+e);
		}
		finally {
		try {
			if(file !=null)
				file.close();
		} catch (IOException e) {
			System.out.println("Exception occured:: "+e);
		}
	}
		
	}
}
