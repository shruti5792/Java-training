package java_lang_package_assignment1;

public class CountObjects {

	public static int noOfObjects=0;

	public CountObjects() {
		noOfObjects++;
	}
	
	
}
