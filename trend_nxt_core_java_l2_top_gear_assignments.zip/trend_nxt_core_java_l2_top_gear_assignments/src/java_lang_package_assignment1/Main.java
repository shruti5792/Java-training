package java_lang_package_assignment1;

public class Main {

	public static void main(String[] args) {
		//Call noOfObjects var and check no of objects created
		CountObjects c1 = new CountObjects();
		CountObjects c2 = new CountObjects();
		CountObjects c3 = new CountObjects();
		CountObjects c4 =c3;
		
		System.out.println(CountObjects.noOfObjects);
	}

}
