package microservices.auth.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import microservices.auth.model.User;
import microservices.auth.repository.RoleRepository;
import microservices.auth.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private RoleRepository roleRepository;
    @Autowired
    private BCryptPasswordEncoder bCryptPasswordEncoder;
	public void save(User user) {
		    }
	
	public User findByUsername(String username) {
		 return userRepository.findByUsername(username);
	}

    
}